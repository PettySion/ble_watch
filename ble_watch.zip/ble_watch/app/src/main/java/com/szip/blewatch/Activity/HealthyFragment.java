package com.szip.blewatch.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.szip.blewatch.MyApplication;
import com.szip.blewatch.R;
import com.szip.blewatch.base.View.BaseFragment;


import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.IOException;
import java.util.Calendar;
import java.util.Locale;


import static android.content.Context.LOCATION_SERVICE;
import static android.content.Context.MODE_PRIVATE;


/**
 * Created by Administrator on 2019/12/1.
 */

public class HealthyFragment extends BaseFragment{



    @Override
    protected int getLayoutId() {
        return R.layout.app_fragment_healthy;
    }

    @Override
    protected void afterOnCreated(Bundle savedInstanceState) {

    }


}
