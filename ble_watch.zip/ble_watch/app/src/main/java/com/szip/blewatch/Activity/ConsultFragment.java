package com.szip.blewatch.Activity;

import android.os.Bundle;

import com.szip.blewatch.R;
import com.szip.blewatch.base.View.BaseFragment;

public class ConsultFragment extends BaseFragment {
    @Override
    protected int getLayoutId() {
        return R.layout.app_fragment_consult;
    }

    @Override
    protected void afterOnCreated(Bundle savedInstanceState) {

    }
}
