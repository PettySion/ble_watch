package com.szip.blewatch.Activity;

import android.os.Bundle;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTabHost;
import com.szip.blewatch.R;
import com.szip.blewatch.View.HostTabView;
import com.szip.blewatch.base.View.BaseActivity;

import java.util.ArrayList;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @author ddnosh
 * @website http://blog.csdn.net/ddnosh
 */
public class MainActivity extends BaseActivity implements IMainView{

    private ArrayList<HostTabView> mTableItemList;
    @BindView(R.id.layout)
    RelativeLayout layout;
    @BindView(android.R.id.tabhost)
    FragmentTabHost fragmentTabHost;
    private IMainPrisenter iMainPrisenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_activty_main);

//        mHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                ARouter.getInstance().build("/main/main")
//                        .withString(Constant.AROUTER_FROM, "splash")
//                        .navigation();
//            }
//        }, 2000);

        ButterKnife.bind(this);
        layout = findViewById(R.id.layout);
        iMainPrisenter = new MainPresenterImpl(this,this);
        iMainPrisenter.checkBluetoochState();
        initHost();
    }


    @Override
    public void initHostFinish(ArrayList<HostTabView> hostTabViews) {
        mTableItemList =hostTabViews;
    }

    /**
     * 初始化选项卡视图
     * */
    private void initHost() {
        //实例化FragmentTabHost对象
        fragmentTabHost = findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(this,getSupportFragmentManager(),android.R.id.tabcontent);
        iMainPrisenter.initHost(fragmentTabHost);
    }


}
