package com.szip.blewatch.Activity;
import com.szip.blewatch.View.HostTabView;

import java.util.ArrayList;

public interface IMainView {
    void initHostFinish(ArrayList<HostTabView> hostTabViews);
}
