package com.szip.blewatch.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.szip.blewatch.MyApplication;
import com.szip.blewatch.R;
import com.szip.blewatch.base.View.BaseFragment;


import java.util.Locale;

/**
 * Created by Administrator on 2019/12/1.
 */

public class SportFragment extends BaseFragment{


    @Override
    protected int getLayoutId() {
        return R.layout.app_fragment_sport;
    }

    @Override
    protected void afterOnCreated(Bundle savedInstanceState) {


    }


}
