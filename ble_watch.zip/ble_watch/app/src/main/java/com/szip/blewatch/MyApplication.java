package com.szip.blewatch;

import com.szip.blewatch.base.BaseApplication;

/**
 * @author ddnosh
 * @website http://blog.csdn.net/ddnosh
 */
public class MyApplication extends BaseApplication {

    @Override
    public void onCreate() {
        super.onCreate();

    }
}
