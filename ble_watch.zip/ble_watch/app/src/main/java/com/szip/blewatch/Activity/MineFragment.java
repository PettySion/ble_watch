package com.szip.blewatch.Activity;

import android.Manifest;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.szip.blewatch.MyApplication;
import com.szip.blewatch.R;
import com.szip.blewatch.base.View.BaseFragment;


import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;


import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Administrator on 2019/12/1.
 */

public class MineFragment extends BaseFragment{

    @Override
    protected int getLayoutId() {
        return R.layout.app_fragment_mine;
    }

    @Override
    protected void afterOnCreated(Bundle savedInstanceState) {

    }


}
