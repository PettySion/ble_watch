package debug;

import com.szip.blewatch.base.BaseApplication;

public class MainApplication extends BaseApplication {
    @Override
    public void onCreate() {
        super.onCreate();

    }
}