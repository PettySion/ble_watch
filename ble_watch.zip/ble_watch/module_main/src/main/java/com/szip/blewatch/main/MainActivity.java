package com.szip.blewatch.main;

import android.os.Bundle;
import android.widget.Toast;


import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;
import com.szip.blewatch.base.Constant;
import com.szip.blewatch.base.View.BaseActivity;
import com.szip.blewatch.base.service.ILoginModuleService;

/**
 * @author ddnosh
 * @website http://blog.csdn.net/ddnosh
 */

@Route(path = "/main/main")
public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_main);

        ARouter.getInstance().inject(this);

        ILoginModuleService loginModuleServiceImpl = (ILoginModuleService) ARouter.getInstance().build("/login/service").navigation();
        if (loginModuleServiceImpl.isLogin()) {
            Toast.makeText(this, "You are logon!", Toast.LENGTH_SHORT).show();
        } else {
            ARouter.getInstance().build("/login/main")
                    .withString(Constant.AROUTER_FROM, "main")
                    .navigation();
        }
    }
}
