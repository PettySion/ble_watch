package com.szip.blewatch.base;

/**
 * @author ddnosh
 * @website http://blog.csdn.net/ddnosh
 */
public class Constant {

    public static final String AROUTER_FROM = "arouter_from";
}
