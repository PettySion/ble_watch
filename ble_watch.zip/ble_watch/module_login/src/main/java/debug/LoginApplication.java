package debug;

import android.app.Application;

import com.szip.blewatch.base.BaseApplication;

public class LoginApplication extends BaseApplication {
    @Override
    public void onCreate() {
        super.onCreate();

    }
}