package com.szip.blewatch.login;

import android.os.Bundle;
import android.widget.Toast;

import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;
import com.szip.blewatch.base.Constant;
import com.szip.blewatch.base.View.BaseActivity;

/**
 * @author ddnosh
 * @website http://blog.csdn.net/ddnosh
 */

@Route(path = "/login/main")
public class LoginActivity extends BaseActivity {

    @Autowired(name = Constant.AROUTER_FROM)
    String from;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_main);

        ARouter.getInstance().inject(this);

        Toast.makeText(this, from, Toast.LENGTH_SHORT).show();
    }
}
